--[[
Linguagem: Lua
Paradigma: Procedural
•OlaMundo - Programa que imprime “Olá Mundo” na tela.
Hello World :D
--]]

print("Olá Mundo")
