#=
Linguagem: Julia
Paradigma = Funcional
•OlaMundo - Programa que imprime “Olá Mundo” na tela.
Hello World :D
=#

println("Olá Mundo")
