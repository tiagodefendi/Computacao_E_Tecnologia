=begin
Linguagem: Ruby
Paradigma = Orientada a Objetos (POO)
•OlaMundo - Programa que imprime “Olá Mundo” na tela.
Hello World :D
=end

puts "Olá Mundo"
